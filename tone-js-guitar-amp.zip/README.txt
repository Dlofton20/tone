A Pen created at CodePen.io. You can find this one at https://codepen.io/iamjoshellis/pen/ZOAzrN.

 *Must be used over https for web audio API to work.*

For Codepen meetup London. 