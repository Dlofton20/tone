var _createClass = function () {function defineProperties(target, props) {for (var i = 0; i < props.length; i++) {var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);}}return function (Constructor, protoProps, staticProps) {if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;};}();function _defineProperty(obj, key, value) {if (key in obj) {Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });} else {obj[key] = value;}return obj;}function _classCallCheck(instance, Constructor) {if (!(instance instanceof Constructor)) {throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self, call) {if (!self) {throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call && (typeof call === "object" || typeof call === "function") ? call : self;}function _inherits(subClass, superClass) {if (typeof superClass !== "function" && superClass !== null) {throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);}subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;} // if (location.protocol !== "https:") location.protocol = "https:";
var
Control = function (_React$Component) {_inherits(Control, _React$Component);function Control() {_classCallCheck(this, Control);return _possibleConstructorReturn(this, (Control.__proto__ || Object.getPrototypeOf(Control)).apply(this, arguments));}_createClass(Control, [{ key: "render", value: function render()
    {var _this2 = this;
      var controlRotation = {
        transform: "rotate(" + 260 * this.props.controlValue + "deg)" };

      return (
        React.createElement("svg", { className: "control", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 70.684 71.293" },
          React.createElement("g", null,
            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 5.5361 62.6836)" }, "0"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "14.15", y2: "55.257" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.1);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 0.8696 48.4258)" }, "1"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "8.796", y2: "44.142" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.2);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 0 33.8428)" }, "2"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "8.856", y2: "31.805" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.3);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 5.9961 20.3257)" }, "3"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "14.318", y2: "20.743" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.4);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 17.584 10.5728)" }, "4"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "24.077", y2: "13.195" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.5);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 33.4302 7.1035)" }, "5"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "36.156", y2: "10.688" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.6);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 47.6943 10.5728)" }, "6"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "48.112", y2: "13.731" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.7);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 59.8574 20.3257)" }, "7"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "57.524", y2: "21.707" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.8);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 65.3652 33.8428)" }, "8"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "62.488", y2: "33.002" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 0.9);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 65.4355 48.4258)" }, "9"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "61.997", y2: "45.329" })),

            React.createElement("g", { className: "control__indicator", onClick: function onClick() {_this2.props.handleChange(_this2.props.controlFor, 1);} },
              React.createElement("text", { transform: "matrix(1 0 0 1 58.7549 62.6836)" }, "10"),
              React.createElement("line", { x1: "35.546", y1: "38.104", x2: "56.152", y2: "56.194" }))),


          React.createElement("g", { className: "control__knob", style: controlRotation },
            React.createElement("circle", { fill: "#c0c0c0", stroke: "#323232", strokeWidth: "2", strokeMiterlimit: "10", cx: "35.546", cy: "38.104", r: "17.877" }),
            React.createElement("circle", { fill: "#FAFAFA", stroke: "#7C7C7C", strokeWidth: "2", strokeMiterlimit: "10", cx: "26.401", cy: "45.436", r: "2.458" })),

          React.createElement("text", { className: "control__name", textAnchor: "middle", x: "50%", y: "100%" }, this.props.controlName)));


    } }]);return Control;}(React.Component);var


Preset = function (_React$Component2) {_inherits(Preset, _React$Component2);function Preset() {_classCallCheck(this, Preset);return _possibleConstructorReturn(this, (Preset.__proto__ || Object.getPrototypeOf(Preset)).apply(this, arguments));}_createClass(Preset, [{ key: "render", value: function render()
    {var _this4 = this;
      return (
        React.createElement("div", { className: "preset" },
          React.createElement("button", { className: "preset__btn", onClick: function onClick() {_this4.props.handlePreset(_this4.props.preset);} },
            this.props.emoji)));



    } }]);return Preset;}(React.Component);var


ControlGroup = function (_React$Component3) {_inherits(ControlGroup, _React$Component3);function ControlGroup() {_classCallCheck(this, ControlGroup);return _possibleConstructorReturn(this, (ControlGroup.__proto__ || Object.getPrototypeOf(ControlGroup)).apply(this, arguments));}_createClass(ControlGroup, [{ key: "render", value: function render()
    {
      return (
        React.createElement("div", { className: "control-group" },
          React.createElement("span", { className: "control-group__name" }, this.props.groupName),
          React.createElement("div", { className: "control-group__controls" },
            this.props.children)));



    } }]);return ControlGroup;}(React.Component);var


App = function (_React$Component4) {_inherits(App, _React$Component4);
  function App(props) {_classCallCheck(this, App);var _this6 = _possibleConstructorReturn(this, (App.__proto__ || Object.getPrototypeOf(App)).call(this,
    props));
    _this6.handleChange = _this6.handleChange.bind(_this6);
    _this6.handlePreset = _this6.handlePreset.bind(_this6);
    _this6.state = {
      gainIn: 0,
      distWet: 0,
      distDirt: 0,
      delayWet: 0,
      delayTime: 0,
      delayFeedback: 0,
      tremWet: 0,
      tremFreq: 0,
      tremDepth: 0,
      verbWet: 0,
      verbRoom: 0,
      chorusWet: 0,
      chorusFreq: 0,
      chorusDepth: 0 };

    // Setup signals & effects
    _this6.input = new Tone.Microphone();
    _this6.input.open(function () {_this6.input.start();});
    _this6.gainIn = new Tone.Gain();
    _this6.distortion = new Tone.Distortion();
    _this6.feedbackDelay = new Tone.FeedbackDelay();
    _this6.tremolo = new Tone.Tremolo().start();
    _this6.reverb = new Tone.JCReverb();
    _this6.chorus = new Tone.Chorus();
    _this6.input.chain(
    _this6.gainIn,
    _this6.distortion,
    _this6.tremolo,
    _this6.chorus,
    _this6.feedbackDelay,
    _this6.reverb,
    Tone.Master);

    // Set Deafaults
    _this6.setAmpState();return _this6;
  }_createClass(App, [{ key: "componentDidUpdate", value: function componentDidUpdate()
    {
      this.setAmpState();
    } }, { key: "setAmpState", value: function setAmpState()
    {
      this.gainIn.gain.value = this.state.gainIn;
      this.distortion.wet.value = this.state.distWet;
      this.distortion.distortion = this.state.distDirt;
      this.feedbackDelay.wet.value = this.state.delayWet;
      this.feedbackDelay.delayTime.value = this.state.delayTime;
      this.feedbackDelay.feedback.value = this.state.delayFeedback;
      this.tremolo.wet.value = this.state.tremWet;
      this.tremolo.frequency.value = this.state.tremFreq * 10;
      this.tremolo.depth.value = this.state.tremDepth;
      this.reverb.wet.value = this.state.verbWet;
      this.reverb.roomSize.value = this.state.verbRoom;
      this.chorus.wet.value = this.state.chorusWet;
      this.chorus.frequency.value = this.state.chorusFreq * 5;
      this.chorus.depth = this.state.chorusDepth;
    } }, { key: "handleChange", value: function handleChange(
    control, val) {
      this.setState(_defineProperty({}, control, val));
    } }, { key: "handlePreset", value: function handlePreset(
    preset) {
      this.setState(presets[preset]);
    } }, { key: "render", value: function render()
    {
      return (
        React.createElement("div", { className: "app" },
          React.createElement(ControlGroup, { groupName: "Input" },
            React.createElement(Control, {
              controlName: "Gain",
              controlFor: "gainIn",
              controlValue: this.state.gainIn,
              handleChange: this.handleChange })),


          React.createElement(ControlGroup, { groupName: "Distortion" },
            React.createElement(Control, {
              controlName: "Mix",
              controlFor: "distWet",
              controlValue: this.state.distWet,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Dirt",
              controlFor: "distDirt",
              controlValue: this.state.distDirt,
              handleChange: this.handleChange })),


          React.createElement(ControlGroup, { groupName: "Tremolo" },
            React.createElement(Control, {
              controlName: "Mix",
              controlFor: "tremWet",
              controlValue: this.state.tremWet,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Rate",
              controlFor: "tremFreq",
              controlValue: this.state.tremFreq,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Depth",
              controlFor: "tremDepth",
              controlValue: this.state.tremDepth,
              handleChange: this.handleChange })),


          React.createElement(ControlGroup, { groupName: "Chorus" },
            React.createElement(Control, {
              controlName: "Mix",
              controlFor: "chorusWet",
              controlValue: this.state.chorusWet,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Rate",
              controlFor: "chorusFreq",
              controlValue: this.state.chorusFreq,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Depth",
              controlFor: "chorusDepth",
              controlValue: this.state.chorusDepth,
              handleChange: this.handleChange })),


          React.createElement(ControlGroup, { groupName: "Delay" },
            React.createElement(Control, {
              controlName: "Mix",
              controlFor: "delayWet",
              controlValue: this.state.delayWet,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Time",
              controlFor: "delayTime",
              controlValue: this.state.delayTime,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Feedback",
              controlFor: "delayFeedback",
              controlValue: this.state.delayFeedback,
              handleChange: this.handleChange })),


          React.createElement(ControlGroup, { groupName: "Reverb" },
            React.createElement(Control, {
              controlName: "Mix",
              controlFor: "verbWet",
              controlValue: this.state.verbWet,
              handleChange: this.handleChange }),

            React.createElement(Control, {
              controlName: "Room",
              controlFor: "verbRoom",
              controlValue: this.state.verbRoom,
              handleChange: this.handleChange })),


          React.createElement(ControlGroup, { groupName: "Presets" },
            React.createElement(Preset, {
              emoji: "\uD83D\uDCA4",
              preset: "delay",
              handlePreset: this.handlePreset }),

            React.createElement(Preset, {
              emoji: "\uD83E\uDD18",
              preset: "rock",
              handlePreset: this.handlePreset }),

            React.createElement(Preset, {
              emoji: "\uD83D\uDE0E",
              preset: "blues",
              handlePreset: this.handlePreset }),

            React.createElement(Preset, {
              emoji: "\uD83D\uDC96",
              preset: "clean",
              handlePreset: this.handlePreset }),

            React.createElement(Preset, {
              emoji: "\u2620\uFE0F",
              preset: "billTed",
              handlePreset: this.handlePreset }))));




    } }]);return App;}(React.Component);


ReactDOM.render(
React.createElement(App, null),
document.getElementById('root'));


var presets = {
  'delay': {
    gainIn: 1,
    distWet: 0,
    distDirt: 0,
    delayWet: 0.4,
    delayTime: 0.3,
    delayFeedback: 0.5,
    tremWet: 0,
    tremFreq: 0,
    tremDepth: 0,
    verbWet: 0,
    verbRoom: 0,
    chorusWet: 0,
    chorusFreq: 0,
    chorusDepth: 0 },

  'rock': {
    gainIn: 1,
    distWet: 1,
    distDirt: 1,
    delayWet: 0,
    delayTime: 0,
    delayFeedback: 0,
    tremWet: 0,
    tremFreq: 0,
    tremDepth: 0,
    verbWet: 0.1,
    verbRoom: 0.1,
    chorusWet: 0,
    chorusFreq: 0,
    chorusDepth: 0 },

  'clean': {
    gainIn: 1,
    distWet: 0,
    distDirt: 0,
    delayWet: 0.2,
    delayTime: 0.4,
    delayFeedback: 0.4,
    tremWet: 0,
    tremFreq: 0,
    tremDepth: 0,
    verbWet: 0.3,
    verbRoom: 0.3,
    chorusWet: 0.7,
    chorusFreq: 0.1,
    chorusDepth: 0.5 },

  'blues': {
    gainIn: 1,
    distWet: 0.4,
    distDirt: 0.3,
    delayWet: 0,
    delayTime: 0,
    delayFeedback: 0,
    tremWet: 0.7,
    tremFreq: 0.6,
    tremDepth: 0.9,
    verbWet: 0.3,
    verbRoom: 0.3,
    chorusWet: 0,
    chorusFreq: 0,
    chorusDepth: 0 },

  'billTed': {
    gainIn: 1,
    distWet: 1,
    distDirt: 1,
    delayWet: 1,
    delayTime: 1,
    delayFeedback: 1,
    tremWet: 1,
    tremFreq: 1,
    tremDepth: 1,
    verbWet: 1,
    verbRoom: 1,
    chorusWet: 1,
    chorusFreq: 1,
    chorusDepth: 1 } };